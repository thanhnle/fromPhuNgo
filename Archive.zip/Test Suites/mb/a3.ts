<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>a3</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>b08c4021-4f1f-40f1-98d9-fd434358077a</testSuiteGuid>
   <testCaseLink>
      <guid>de5013fd-afb2-465b-92a7-1d7522bf949c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/sA</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7081842c-b770-408d-b179-6d90c5def632</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/a3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>93a82548-df64-4469-a2cb-8cdaa747a63f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/a3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3b2dab24-d23c-4010-bcc6-90e369f72ec2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/a3</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
