<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>c</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>350b6aaa-d2aa-4a05-a64b-8b7ada0dad75</testSuiteGuid>
   <testCaseLink>
      <guid>beafea75-ebb3-4880-bb1b-55f88a4d45c7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/sA</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>336b3f6a-8edd-41bd-b081-9d0b4f53b219</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/a3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a5062c8e-6c5c-4144-b612-cedc87d1a8ce</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/a</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f692a180-5087-4db2-ba30-398a861c0c1d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/a5</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>73a1f8ae-bc37-4062-9ccc-2bf71b8f6b8b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/sN</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>704ff837-efed-4a4c-8e36-a3accf463132</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/mb/c/m</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
