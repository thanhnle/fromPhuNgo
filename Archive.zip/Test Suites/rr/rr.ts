<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>rr</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>phu.ngo@katalon.com;</mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>7dd0dbda-b209-4941-bad3-3378cd6d4351</testSuiteGuid>
   <testCaseLink>
      <guid>6e4a71d9-6f0b-4558-887b-3ef0486778de</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/rr/rrf</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>975117a2-99d1-455f-9bc7-d5a042bc4f50</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/rr/rrp</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
