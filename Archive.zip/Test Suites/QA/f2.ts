<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>f2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>bdfdbef6-c5a2-44cb-a1c7-d9f4b6933cb5</testSuiteGuid>
   <testCaseLink>
      <guid>14b9a9ac-dcbb-457a-856f-7d5a3db2ac94</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/DemoQA/form</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>eee75cc2-1bc1-47b7-973a-39475284c044</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/dQA/f2</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>eee75cc2-1bc1-47b7-973a-39475284c044</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>ID</value>
         <variableId>d7717e5e-bc0a-4ecf-b329-7b3690d721aa</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>eee75cc2-1bc1-47b7-973a-39475284c044</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>First name</value>
         <variableId>22c3a13a-6f24-4338-b32a-64d9c8277983</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>eee75cc2-1bc1-47b7-973a-39475284c044</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Last name</value>
         <variableId>38910d3b-02f6-4ed8-b8f0-4984f475f47a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>eee75cc2-1bc1-47b7-973a-39475284c044</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Email</value>
         <variableId>178c1d17-6c5d-428f-90b8-d9cc0d726c3c</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>eee75cc2-1bc1-47b7-973a-39475284c044</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Gender</value>
         <variableId>640616a0-710f-4301-a5fc-4ee3fb7a318e</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>eee75cc2-1bc1-47b7-973a-39475284c044</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Phone number</value>
         <variableId>0fc13878-2409-4cb4-b27f-3a14ed126637</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
