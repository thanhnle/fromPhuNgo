<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>f1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>huyphu111@gmail.com;phu.ngo@katalon.com;</mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>7a5995e8-2602-4183-bcaf-41f9d953c33a</testSuiteGuid>
   <testCaseLink>
      <guid>60d029e4-2464-4cef-8d2b-3c040c362fed</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/vs/TC1</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>89f76880-dbcf-4dba-bffa-33e4cc5c2f1d</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/dQA/f1</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>89f76880-dbcf-4dba-bffa-33e4cc5c2f1d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>ID</value>
         <variableId>b0f8f408-f30d-49c9-b8a3-5fc148ed08ae</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>89f76880-dbcf-4dba-bffa-33e4cc5c2f1d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>First name</value>
         <variableId>41b6b472-7c4e-420f-8202-92f4397b1ae8</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>89f76880-dbcf-4dba-bffa-33e4cc5c2f1d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Last name</value>
         <variableId>6a123d0e-33da-4d8c-9ca1-28e85eeea838</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>89f76880-dbcf-4dba-bffa-33e4cc5c2f1d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Email</value>
         <variableId>55f3302e-6d45-4be2-9d6f-f78a61f2005c</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>89f76880-dbcf-4dba-bffa-33e4cc5c2f1d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Gender</value>
         <variableId>102a1255-f870-4162-8956-408a7e7baa4f</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>89f76880-dbcf-4dba-bffa-33e4cc5c2f1d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Phone number</value>
         <variableId>1ed782e0-5f67-448b-b992-b53c0d713424</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
