<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>rd</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>dd806d27-4d75-46dc-bd00-cf19d48547db</testSuiteGuid>
   <testCaseLink>
      <guid>d6ea9a87-c023-4a3b-8798-3607a250e9b5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/rd/rd</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1487fa5b-d74b-4a7b-bfbb-592dd1db10e0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/rd/rd</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dbc2ab80-f3a0-47bc-9148-20d9b2ac8c73</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/rd/rd</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
