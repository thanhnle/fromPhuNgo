<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>json</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>a8681c8d-1703-49db-b5f1-ae9ef09f44ba</testSuiteGuid>
   <testCaseLink>
      <guid>c57fd0e2-b582-4747-9cfe-fc6bf37fe4cb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/td</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fe2a7365-dd70-4bfd-bb76-15ffa2c537de</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/cm</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>25867c5a-b610-44e3-9704-980a19909064</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/po</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
