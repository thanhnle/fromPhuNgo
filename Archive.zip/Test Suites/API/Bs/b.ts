<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>b</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>4de82b96-e79a-48f3-9e1c-5c764f831c22</testSuiteGuid>
   <testCaseLink>
      <guid>332dbc11-187e-4902-a8e0-9540e4fae0e8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/bs</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4c0c7f62-5ad2-4dff-b934-ec7e940febaa</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/b2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0039110b-c132-4fab-83f8-d7db96e30df1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/b1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3bac817b-6c78-49d8-ae32-0e03bf56a1ff</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/bn</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
