<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>ma</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>7e7e6758-384d-4ea8-82de-d148a5092142</testSuiteGuid>
   <testCaseLink>
      <guid>862213ec-ec6b-4976-860d-9e6967fbf712</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/ma</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fdac2277-cbf3-4b0e-bb6a-721af84c5b05</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/ma</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
