<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>rr</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>c1898ee8-702a-4e55-9379-e6b38c8619ab</testSuiteGuid>
   <testCaseLink>
      <guid>b5c3ca40-5fbf-465f-8909-becd79765d3d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/un</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0ab777c5-a9f4-492c-9331-19c9fa74fb6a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/us</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0450e56f-d5ca-4e27-9c20-b358a3758dbc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/u</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
