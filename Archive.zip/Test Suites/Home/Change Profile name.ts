<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Change Profile name</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>1291f641-0b6b-4f06-ba71-064d1555faa3</testSuiteGuid>
   <testCaseLink>
      <guid>430fb74e-2c0a-4384-a9d2-44726f58a951</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KMS - Home/Login/Valid Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>43b300d7-01f7-43d4-ba4e-1e5d92f2e9a6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KMS - Home/Home Screen/Change Profile Name/Happy Case</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>560f6c35-866d-4d9c-af6c-251fba328325</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KMS - Home/Home Screen/Change Profile Name/Reset Profile Name</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
