<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Login</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>b31b8372-1d27-43ac-86db-9c4cb12d4b17</testSuiteGuid>
   <testCaseLink>
      <guid>8b892112-a49b-4246-8989-29a85560d524</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KMS - Home/Login/Invalid Login - missing required fields</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>74b46076-8749-4471-8476-382ef092e41f</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Login/Invalid logins - missing fields</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>74b46076-8749-4471-8476-382ef092e41f</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Username</value>
         <variableId>9fab0a9e-4c84-4fad-b424-148cc930ead0</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>74b46076-8749-4471-8476-382ef092e41f</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Password</value>
         <variableId>e0085c5f-fe1e-48b5-939a-9f958c0e642d</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>7e00ead9-6024-443a-8d6d-7552e7705bfe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KMS - Home/Login/Invalid Login - Non-existing Account</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e926832c-f52f-4e03-926f-11be74eb5ccf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KMS - Home/Login/Valid Login</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
