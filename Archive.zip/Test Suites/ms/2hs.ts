<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>2hs</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>72f80179-b033-41fe-af66-c1515d8b8fee</testSuiteGuid>
   <testCaseLink>
      <guid>e2d0b5ed-67d9-41e0-986c-481c1a4a9b75</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/cm</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ac57607e-e1b4-4e9a-b834-41db2d2d77d9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/po</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2f31afdd-f8ea-4980-bdb0-99633d06019c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/td</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>17d4e6f7-ae16-4121-bdb2-723a2cf44413</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/cm</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0b3aa4bb-9b76-49e1-bcd9-94b58b12c42e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/po</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8dabe131-fc0d-418e-b4b1-1b9d423bdd4c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/td</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3cc1954a-c059-4b84-90a1-8a7bd5674ec5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/cm</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9c385dab-89a2-42b4-ac99-ab147813ac9a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/po</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9b852d09-39b6-47af-b129-2ff8c5deeef0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/td</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8b3b26eb-a3f4-4e83-af6e-843f09babaec</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/u</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3afeeb39-5641-412b-9183-6e0e5e2ba605</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/un</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9c9d930b-ac1b-4ff9-a4f1-b85d46a673ec</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/us</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>95cd0b92-ec78-429f-8634-e1145dfe31fb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/b1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0eaf6eb3-af55-4f38-a8c4-937d4a6d3978</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/b2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a8868eee-8bf8-42b0-9e11-838d53b63c22</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/bn</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7ca7e63e-b7c2-415d-81e4-e06fbeb8a100</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/bs</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b86139c6-31ed-42de-ae07-8ec3730bdbea</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/cm</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e6edf988-710a-4c27-b307-520328f99418</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/po</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9e3dd3e0-5652-4aed-b7a1-4de373685c56</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/js/td</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>21b249ce-3b06-4b90-9091-3c7048305711</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/u</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f47e6e91-e8e6-46bb-be18-9c07c109d29c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/un</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>67dbccca-caca-43e6-b30d-f0867dbd2b92</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/rr/us</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e938c2d8-adee-401f-9556-182e8496ad86</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/b1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ae833fc7-fecd-4d5e-b354-ccd38b82e313</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/b2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6a5be080-3360-49e6-961e-dda3e3ab7a75</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/APIs/b/book/bn</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>12b7fb94-ad92-4030-aa00-6eb69f3db2bb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/APIs/b/book/bs</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
