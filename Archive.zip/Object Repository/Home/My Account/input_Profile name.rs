<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_Profile name</name>
   <tag></tag>
   <elementGuidId>b0efe75c-43f2-47b5-9e3a-29163b67aca3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//user-profile//input[@type='text']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
